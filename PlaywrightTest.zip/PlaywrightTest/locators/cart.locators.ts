export const CartLocators = {
  pageTitle: '[data-test="title"]',
  cartItem: '[data-test="inventory-item"]',
  itemName: '[data-test="inventory-item-name"]',
  itemPrice: '[data-test="inventory-item-price"]',
  checkoutButton: '[data-test="checkout"]',
} as const;
