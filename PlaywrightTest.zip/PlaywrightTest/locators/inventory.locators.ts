export const InventoryLocators = {
  pageTitle: '[data-test="title"]',
  inventoryList: '[data-test="inventory-list"]',
  inventoryItem: '[data-test="inventory-item"]',
  itemName: '[data-test="inventory-item-name"]',
  itemPrice: '[data-test="inventory-item-price"]',
  sortDropdown: '[data-test="product-sort-container"]',
  cartLink: '[data-test="shopping-cart-link"]',
  cartBadge: '[data-test="shopping-cart-badge"]',
  addToCartButton: 'button[data-test^="add-to-cart"]',
} as const;
