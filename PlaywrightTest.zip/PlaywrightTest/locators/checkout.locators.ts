export const CheckoutLocators = {
  pageTitle: '[data-test="title"]',
  // Step one: customer information
  firstName: '[data-test="firstName"]',
  lastName: '[data-test="lastName"]',
  postalCode: '[data-test="postalCode"]',
  continueButton: '[data-test="continue"]',
  errorMessage: '[data-test="error"]',
  // Step two: overview
  cartItem: '[data-test="inventory-item"]',
  itemName: '[data-test="inventory-item-name"]',
  itemPrice: '[data-test="inventory-item-price"]',
  subtotalLabel: '[data-test="subtotal-label"]',
  taxLabel: '[data-test="tax-label"]',
  totalLabel: '[data-test="total-label"]',
  finishButton: '[data-test="finish"]',
  // Complete
  completeHeader: '[data-test="complete-header"]',
  completeText: '[data-test="complete-text"]',
} as const;
