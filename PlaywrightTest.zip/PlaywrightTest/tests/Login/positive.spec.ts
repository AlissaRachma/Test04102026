import { test } from '@playwright/test';
import { LoginPage } from '../../pages/login-pages.ts';

test('Positive Login', async ({ page }) => {

    const loginPage = new LoginPage(page);

    await loginPage.open();

    await loginPage.login('Admin', 'admin123');
    console.log("Login selesai");
});