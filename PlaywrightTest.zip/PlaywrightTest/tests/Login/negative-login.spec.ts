import { test, expect } from '../../fixtures/pages.fixture';
import { users } from '../../test-data/users';
import { messages } from '../../test-data/messages';

test.describe('Login - negative', () => {
  test.beforeEach(async ({ loginPage }) => {
    await loginPage.goto();
  });

  test('wrong credentials show the correct error message', async ({ loginPage, page }) => {
    await loginPage.login(users.invalid.username, users.invalid.password);
    await loginPage.expectError(messages.invalidCredentials);
    await expect(page).not.toHaveURL(/inventory/);
  });

  test('valid username with wrong password shows the correct error message', async ({ loginPage }) => {
    await loginPage.login(users.standard.username, users.invalid.password);
    await loginPage.expectError(messages.invalidCredentials);
  });

  test('empty username shows a "Username is required" error', async ({ loginPage }) => {
    await loginPage.login('', users.standard.password);
    await loginPage.expectError(messages.usernameRequired);
  });

  test('locked out user cannot log in', async ({ loginPage }) => {
    await loginPage.login(users.lockedOut.username, users.lockedOut.password);
    await loginPage.expectError(messages.lockedOut);
  });
});
