import { test } from '../../fixtures/pages.fixture';
import { users } from '../../test-data/users';

test.describe('Login - positive', () => {
  test('standard user logs in and lands on the Product Listing page', async ({ loginPage, inventoryPage }) => {
    await loginPage.goto();
    await loginPage.login(users.standard.username, users.standard.password);
    await inventoryPage.expectLoaded();
  });
});
