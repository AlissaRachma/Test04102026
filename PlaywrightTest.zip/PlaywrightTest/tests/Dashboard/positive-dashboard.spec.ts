import { test, expect } from '../../fixtures/pages.fixture';

test.describe('Dashboard (Product Listing) - sorting', () => {
  test('Price (high to low) puts the most expensive item first', async ({ loggedInInventory: inventory }) => {
    await inventory.sortBy('hilo');

    const prices = await inventory.getPricesInCents();
    const mostExpensive = Math.max(...prices);

    // The first item is the most expensive in the list...
    expect(await inventory.getFirstItemPriceInCents()).toBe(mostExpensive);
    // ...and the whole list is in descending order.
    expect(prices).toEqual([...prices].sort((a, b) => b - a));
  });
});
