import { test, expect } from '../../fixtures/pages.fixture';
import { customer, productsToBuy } from '../../test-data/checkout.data';
import { messages } from '../../test-data/messages';

test.describe('Checkout - end to end', () => {
  test('add two items, verify cart, verify totals, complete order', async ({
    loggedInInventory: inventory,
    cartPage,
    checkoutPage,
  }) => {
    // 1. Add two distinct items
    await inventory.addProducts(productsToBuy);

    // 2. Cart lists exactly those items
    await inventory.openCart();
    await cartPage.expectLoaded();
    await cartPage.expectItems(productsToBuy);

    // 3. Customer information
    await cartPage.checkout();
    await checkoutPage.fillCustomerInfo(customer);

    // 4. Overview: items match, and Item Total + Tax === Total
    await checkoutPage.expectOverviewLoaded();
    expect((await checkoutPage.getOverviewItemNames()).sort()).toEqual([...productsToBuy].sort());

    const { itemsCents, itemTotalCents, taxCents, totalCents } = await checkoutPage.getOrderSummary();
    const sumOfItems = itemsCents.reduce((a, b) => a + b, 0);

    expect(itemTotalCents, 'Item total equals sum of listed item prices').toBe(sumOfItems);
    expect(itemTotalCents + taxCents, 'Item total + tax equals displayed total').toBe(totalCents);

    // 5. Finish and confirm
    await checkoutPage.finish();
    await checkoutPage.expectOrderComplete(messages.orderComplete);
  });
});
