/**
 * Converts a price string such as "$29.99" or "Item total: $39.98" into integer cents.
 * Working in cents avoids floating-point drift (e.g. 0.1 + 0.2 !== 0.3).
 */
export function toCents(text: string): number {
  const match = text.match(/\d+(?:\.\d+)?/);
  if (!match) throw new Error(`No monetary value found in "${text}"`);
  return Math.round(parseFloat(match[0]) * 100);
}

export function formatCents(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}
