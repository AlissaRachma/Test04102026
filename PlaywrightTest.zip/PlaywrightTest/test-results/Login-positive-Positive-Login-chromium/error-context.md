# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Login\positive.spec.ts >> Positive Login
- Location: tests\Login\positive.spec.ts:4:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('input[name="username"]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('input[name="username"]')

```

# Test source

```ts
  1  | import { Locator,Page,expect } from '@playwright/test';
  2  | 
  3  | export class LoginPage {
  4  |     readonly usernameInput: Locator;
  5  |     readonly passwordInput: Locator;
  6  |     readonly loginButton: Locator;
  7  | 
  8  |     constructor(private page: Page) {
  9  |         this.usernameInput = page.locator('input[name="username"]');
  10 |         this.passwordInput = page.locator('input[name="password"]');
  11 |         this.loginButton = page.getByRole('button', { name: 'Login' });
  12 |     }
  13 |     async open() {
  14 | 
  15 |     await this.page.goto('auth/login');
  16 | 
  17 |     console.log('Current URL:', this.page.url());
  18 | 
  19 | }
  20 |       async login(username: string, password: string) {
> 21 |         await expect(this.usernameInput).toBeVisible();
     |                                          ^ Error: expect(locator).toBeVisible() failed
  22 |         console.log("Isi username");
  23 |         await this.usernameInput.fill(username);
  24 | 
  25 |         await expect(this.passwordInput).toBeVisible();
  26 |         console.log("Isi password");
  27 |         await this.passwordInput.fill(password);
  28 | 
  29 |         await expect(this.loginButton).toBeVisible();
  30 |         console.log("klik button");
  31 |         await this.loginButton.click();
  32 |     }
  33 | }
```