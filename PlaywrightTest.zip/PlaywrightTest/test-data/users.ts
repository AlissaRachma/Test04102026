// Public demo credentials from the SauceDemo landing page; override via .env if needed.
export const users = {
  standard: {
    username: process.env.STANDARD_USER ?? 'standard_user',
    password: process.env.USER_PASSWORD ?? 'secret_sauce',
  },
  lockedOut: {
    username: process.env.LOCKED_OUT_USER ?? 'locked_out_user',
    password: process.env.USER_PASSWORD ?? 'secret_sauce',
  },
  invalid: {
    username: 'invalid_user',
    password: 'wrong_password',
  },
} as const;
