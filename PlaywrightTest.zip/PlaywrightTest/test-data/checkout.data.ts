export const customer = {
  firstName: 'Jane',
  lastName: 'Doe',
  postalCode: '15310',
} as const;

// Two distinct products used by the checkout flow.
export const productsToBuy = ['Sauce Labs Backpack', 'Sauce Labs Bike Light'] as const;
