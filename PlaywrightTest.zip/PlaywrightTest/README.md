# SauceDemo E2E Suite — Playwright + TypeScript

Automated tests for https://www.saucedemo.com using the **Page Object Model**.

## Project structure

```
PlaywrightTest/
├── fixtures/          # Playwright fixtures: page objects + pre-authenticated session
├── locators/          # Selectors only (one file per page) — UI changes are fixed here
├── pages/             # Page Objects: actions + assertions per page (BasePage → LoginPage, ...)
├── test-data/         # Users, customer info, expected messages (no magic strings in tests)
├── utils/             # Helpers (money parsing in integer cents)
├── tests/
│   ├── Login/         # positive-login.spec.ts, negative-login.spec.ts
│   ├── Dashboard/     # positive-dashboard.spec.ts (sorting)
│   └── Checkout/      # positive-checkout.spec.ts (E2E purchase)
├── playwright.config.ts
├── .env.example
└── README.md
```

## Design notes

- **Locators are separated from page logic**, so selector changes never touch test code.
- **Page objects own assertions about their own state** (`expectLoaded`, `expectError`, ...), keeping specs readable.
- **Fixtures** provide page objects and a `loggedInInventory` fixture so tests don't repeat login steps.
- **Money is compared in integer cents** to avoid floating-point errors in `Item Total + Tax = Total`.
- **Products are added by name**, not by position, so tests don't depend on list order.
- **Web-first assertions** (`toHaveText`, `toHaveURL`, `toHaveCount`) auto-wait; there are no hard sleeps.
- **Config/env**: `BASE_URL` and credentials come from `.env` (defaults are SauceDemo's public demo credentials).

## Setup

Prerequisites: Node.js 18+ and npm.

```bash
git clone <your-repo-url>
cd PlaywrightTest
npm install
npx playwright install chromium
cp .env.example .env     # optional; defaults work out of the box
```

## Run

```bash
npm test                 # all tests (headless)
npm run test:headed      # watch the browser
npm run test:login       # Login suite only
npm run test:dashboard   # Sorting suite only
npm run test:checkout    # Checkout E2E only
npm run report           # open the HTML report (playwright-report/)
npm run typecheck        # TypeScript check
```

## Scenarios covered

| Area | Test |
|------|------|
| Login | Valid login redirects to Products page |
| Login | Wrong credentials → `Epic sadface: Username and password do not match any user in this service` |
| Login | Wrong password, empty username, locked-out user (extra negative coverage) |
| Checkout | Add 2 items → cart lists them → fill info → **Item Total + Tax = Total** → "Thank you for your order!" |
| Sorting | "Price (high to low)" → first item is the most expensive and the list is descending |

On failure, screenshots, video and traces are saved to `test-results/`.
