import { Locator,Page,expect } from '@playwright/test';

export class LoginPage {
    readonly usernameInput: Locator;
    readonly passwordInput: Locator;
    readonly loginButton: Locator;

    constructor(private page: Page) {
        this.usernameInput = page.locator('input[name="username"]');
        this.passwordInput = page.locator('input[name="password"]');
        this.loginButton = page.getByRole('button', { name: 'Login' });
    }
    async open() {

    await this.page.goto('auth/login');

    console.log('Current URL:', this.page.url());

}
      async login(username: string, password: string) {
        await expect(this.usernameInput).toBeVisible();
        console.log("Isi username");
        await this.usernameInput.fill(username);

        await expect(this.passwordInput).toBeVisible();
        console.log("Isi password");
        await this.passwordInput.fill(password);

        await expect(this.loginButton).toBeVisible();
        console.log("klik button");
        await this.loginButton.click();
    }
}