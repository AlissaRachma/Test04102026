import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { CartLocators } from '../locators/cart.locators';

export class CartPage extends BasePage {
  private readonly title: Locator;
  private readonly items: Locator;
  private readonly itemNames: Locator;
  private readonly checkoutButton: Locator;

  constructor(page: Page) {
    super(page);
    this.title = page.locator(CartLocators.pageTitle);
    this.items = page.locator(CartLocators.cartItem);
    this.itemNames = page.locator(CartLocators.itemName);
    this.checkoutButton = page.locator(CartLocators.checkoutButton);
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/cart\.html$/);
    await expect(this.title).toHaveText('Your Cart');
  }

  async expectItems(expected: readonly string[]): Promise<void> {
    await expect(this.items).toHaveCount(expected.length);
    // Order-insensitive comparison of what is actually listed.
    const actual = (await this.itemNames.allTextContents()).map((t) => t.trim()).sort();
    expect(actual).toEqual([...expected].sort());
  }

  async checkout(): Promise<void> {
    await this.checkoutButton.click();
  }
}
