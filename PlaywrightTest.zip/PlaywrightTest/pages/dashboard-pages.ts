import { Locator,Page,expect } from '@playwright/test';

export class DashboardPage{



    // ===== Locators =====

    readonly dashboardTitle: Locator;
    readonly adminMenu: Locator;
    readonly pimMenu: Locator;
    readonly leaveMenu: Locator;
    readonly recruitmentMenu: Locator;
    readonly profileMenu: Locator;
    readonly searchInput: Locator;
    readonly collapseButton: Locator;

    constructor(private page: Page) {

        this.dashboardTitle = page.getByRole('heading', { name: 'Dashboard' });

        this.adminMenu = page.getByRole('link', { name: 'Admin' });

        this.pimMenu = page.getByRole('link', { name: 'PIM' });

        this.leaveMenu = page.getByRole('link', { name: 'Leave' });

        this.recruitmentMenu = page.getByRole('link', { name: 'Recruitment' });

        this.profileMenu = page.locator('.oxd-userdropdown-tab');

        this.searchInput = page.getByPlaceholder('Search');

        this.collapseButton = page.locator('button:has(.oxd-icon.bi-chevron-left)');
    }

    // ===== Methods =====

    async verifyDashboardLoaded() {
        await expect(this.dashboardTitle).toBeVisible();
    }

    async clickAdminMenu() {
        await this.adminMenu.click();
    }

    async clickPimMenu() {
        await this.pimMenu.click();
    }

    async clickLeaveMenu() {
        await this.leaveMenu.click();
    }

    async searchMenu(menu: string) {
        await this.searchInput.fill(menu);
    }

    async openProfileMenu() {
        await this.profileMenu.click();
    }

    async collapseSidebar() {
        await this.collapseButton.click();
    }

}