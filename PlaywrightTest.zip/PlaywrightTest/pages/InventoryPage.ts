import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { InventoryLocators } from '../locators/inventory.locators';
import { toCents } from '../utils/money';

export type SortOption = 'az' | 'za' | 'lohi' | 'hilo';

export class InventoryPage extends BasePage {
  readonly title: Locator;
  private readonly items: Locator;
  private readonly itemNames: Locator;
  private readonly itemPrices: Locator;
  private readonly sortDropdown: Locator;
  private readonly cartLink: Locator;
  private readonly cartBadge: Locator;

  constructor(page: Page) {
    super(page);
    this.title = page.locator(InventoryLocators.pageTitle);
    this.items = page.locator(InventoryLocators.inventoryItem);
    this.itemNames = page.locator(InventoryLocators.itemName);
    this.itemPrices = page.locator(InventoryLocators.itemPrice);
    this.sortDropdown = page.locator(InventoryLocators.sortDropdown);
    this.cartLink = page.locator(InventoryLocators.cartLink);
    this.cartBadge = page.locator(InventoryLocators.cartBadge);
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/inventory\.html$/);
    await expect(this.title).toHaveText('Products');
    await expect(this.items.first()).toBeVisible();
  }

  /** Adds a product by its visible name (no dependency on list order). */
  async addToCart(productName: string): Promise<void> {
    const item = this.items.filter({ has: this.page.locator(InventoryLocators.itemName, { hasText: productName }) });
    await item.locator(InventoryLocators.addToCartButton).click();
  }

  async addProducts(names: readonly string[]): Promise<void> {
    for (const name of names) await this.addToCart(name);
    await expect(this.cartBadge).toHaveText(String(names.length));
  }

  async sortBy(option: SortOption): Promise<void> {
    await this.sortDropdown.selectOption(option);
    await expect(this.sortDropdown).toHaveValue(option);
  }

  async getProductNames(): Promise<string[]> {
    return (await this.itemNames.allTextContents()).map((t) => t.trim());
  }

  /** Prices as integer cents, in on-screen order. */
  async getPricesInCents(): Promise<number[]> {
    return (await this.itemPrices.allTextContents()).map(toCents);
  }

  async getFirstItemPriceInCents(): Promise<number> {
    return toCents(await this.itemPrices.first().innerText());
  }

  async openCart(): Promise<void> {
    await this.cartLink.click();
  }
}
