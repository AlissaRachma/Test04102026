import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { CheckoutLocators } from '../locators/checkout.locators';
import { toCents } from '../utils/money';

export interface CustomerInfo {
  firstName: string;
  lastName: string;
  postalCode: string;
}

export interface OrderSummary {
  itemsCents: number[];
  itemTotalCents: number;
  taxCents: number;
  totalCents: number;
}

export class CheckoutPage extends BasePage {
  private readonly title: Locator;
  private readonly firstName: Locator;
  private readonly lastName: Locator;
  private readonly postalCode: Locator;
  private readonly continueButton: Locator;
  private readonly itemNames: Locator;
  private readonly itemPrices: Locator;
  private readonly subtotalLabel: Locator;
  private readonly taxLabel: Locator;
  private readonly totalLabel: Locator;
  private readonly finishButton: Locator;
  private readonly completeHeader: Locator;

  constructor(page: Page) {
    super(page);
    this.title = page.locator(CheckoutLocators.pageTitle);
    this.firstName = page.locator(CheckoutLocators.firstName);
    this.lastName = page.locator(CheckoutLocators.lastName);
    this.postalCode = page.locator(CheckoutLocators.postalCode);
    this.continueButton = page.locator(CheckoutLocators.continueButton);
    this.itemNames = page.locator(CheckoutLocators.itemName);
    this.itemPrices = page.locator(CheckoutLocators.itemPrice);
    this.subtotalLabel = page.locator(CheckoutLocators.subtotalLabel);
    this.taxLabel = page.locator(CheckoutLocators.taxLabel);
    this.totalLabel = page.locator(CheckoutLocators.totalLabel);
    this.finishButton = page.locator(CheckoutLocators.finishButton);
    this.completeHeader = page.locator(CheckoutLocators.completeHeader);
  }

  async fillCustomerInfo(info: CustomerInfo): Promise<void> {
    await expect(this.page).toHaveURL(/\/checkout-step-one\.html$/);
    await expect(this.title).toHaveText('Checkout: Your Information');
    await this.firstName.fill(info.firstName);
    await this.lastName.fill(info.lastName);
    await this.postalCode.fill(info.postalCode);
    await this.continueButton.click();
  }

  async expectOverviewLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(/\/checkout-step-two\.html$/);
    await expect(this.title).toHaveText('Checkout: Overview');
  }

  async getOverviewItemNames(): Promise<string[]> {
    return (await this.itemNames.allTextContents()).map((t) => t.trim());
  }

  async getOrderSummary(): Promise<OrderSummary> {
    const itemsCents = (await this.itemPrices.allTextContents()).map(toCents);
    return {
      itemsCents,
      itemTotalCents: toCents(await this.subtotalLabel.innerText()),
      taxCents: toCents(await this.taxLabel.innerText()),
      totalCents: toCents(await this.totalLabel.innerText()),
    };
  }

  async finish(): Promise<void> {
    await this.finishButton.click();
  }

  async expectOrderComplete(message: string): Promise<void> {
    await expect(this.page).toHaveURL(/\/checkout-complete\.html$/);
    await expect(this.title).toHaveText('Checkout: Complete!');
    await expect(this.completeHeader).toHaveText(message);
  }
}
