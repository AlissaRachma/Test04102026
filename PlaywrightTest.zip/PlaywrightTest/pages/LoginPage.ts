import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { LoginLocators } from '../locators/login.locators';

export class LoginPage extends BasePage {
  private readonly username: Locator;
  private readonly password: Locator;
  private readonly loginButton: Locator;
  private readonly errorMessage: Locator;

  constructor(page: Page) {
    super(page);
    this.username = page.locator(LoginLocators.username);
    this.password = page.locator(LoginLocators.password);
    this.loginButton = page.locator(LoginLocators.loginButton);
    this.errorMessage = page.locator(LoginLocators.errorMessage);
  }

  async goto(): Promise<void> {
    await this.open('/');
    await expect(this.loginButton).toBeVisible();
  }

  async login(username: string, password: string): Promise<void> {
    await this.username.fill(username);
    await this.password.fill(password);
    await this.loginButton.click();
  }

  async expectError(message: string): Promise<void> {
    await expect(this.errorMessage).toBeVisible();
    await expect(this.errorMessage).toHaveText(message);
  }
}
